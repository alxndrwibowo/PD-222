package TugasPertemuan3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Praktikum2_P2_22410100047 {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        int j, b, sb, mb, smb, m, sm;

        System.out.print("Masukkan jumlah penumpang : ");
        j = Integer.parseInt(br.readLine());

        b = j/50;
        sb = j%50;

        mb = sb/15;
        smb = sb%15;

        m = smb/7;
        sm = smb%7;

        if (sm>0) {
            m = m+1;
        }

        System.out.println("Jumlah Bus : " + b);
        System.out.println("Jumlah Mini Bus : " + mb);
        System.out.println("Jumlah Mobil : " + m);

    }
}
